/*
  GALLERY SETTINGS - edit this list to add real photographs.

  For each photo:
  1. Save the image in the assets/images/ folder (for example: assets/images/classroom-1.jpg).
  2. Find the entry below for that category and set:
       src:     "assets/images/classroom-1.jpg"
       alt:     "Short description of the photo"
       caption: "Caption shown under the photo"
  3. Leave src as "" to keep the placeholder.
  4. To add more photos, copy one line and change it.
*/
var GALLERY_ITEMS = [
  { category: "Madrassa Rahmaniyyah", src: "", alt: "", caption: "Madrassa Rahmaniyyah" },
  { category: "Madrassa Rahmaniyyah", src: "", alt: "", caption: "Madrassa Rahmaniyyah" },
  { category: "Masjid-e-Luqman", src: "assets/images/masjid-e-luqman.jpg", alt: "Masjid-e-Luqman building with green domes and palm trees", caption: "Masjid-e-Luqman" },
  { category: "Masjid-e-Luqman", src: "", alt: "", caption: "Masjid-e-Luqman" },
  { category: "IETZA Primary School", src: "", alt: "", caption: "IETZA Primary School" },
  { category: "Darul Mufazamia", src: "", alt: "", caption: "Darul Mufazamia" },
  { category: "Classrooms and educational activities", src: "", alt: "", caption: "Classrooms and educational activities" },
  { category: "Institutional events", src: "", alt: "", caption: "Institutional events" },
  { category: "Campus and facilities", src: "", alt: "", caption: "Campus and facilities" }
];

(function () {
  var grid = document.getElementById('gallery-grid');
  if (!grid) return;
  GALLERY_ITEMS.forEach(function (item) {
    var fig = document.createElement('figure');
    fig.className = 'gallery-item';
    if (item.src) {
      var img = document.createElement('img');
      img.src = item.src;
      img.alt = item.alt || item.caption || '';
      img.loading = 'lazy';
      fig.appendChild(img);
    } else {
      var ph = document.createElement('div');
      ph.className = 'placeholder';
      ph.textContent = '[PHOTO PLACEHOLDER: ' + item.category + ']';
      fig.appendChild(ph);
    }
    var cap = document.createElement('figcaption');
    cap.textContent = item.caption || item.category;
    fig.appendChild(cap);
    grid.appendChild(fig);
  });
})();
